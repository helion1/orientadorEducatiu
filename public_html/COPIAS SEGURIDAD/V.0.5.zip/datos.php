<?php

$host = "192.168.2.208";
$user = "admin";
$pw = "marianao";
$db = "project_x";

$conexion = new mysqli($host, $user, $pw, $db);

#Comprobar la conexión
if ($conexion->connect_error) {
    printf("Conexión fallida: %s", $conexion->connect_error);
    exit();
}

$resultado=$_POST['resultado'];

$q1 = "SELECT curs.nom as nom, curs.descripcio_curta as descripcio_curta, curs.id_curs as id_curs, ".
      "familia.itinerari as itinerari, curs.id_estudis as id_estudis, estudi.requeriments as requeriments ".
      "FROM curs, estudi, familia ".
      "WHERE estudi.id_estudis = curs.id_estudis AND curs.id_familia = familia.id_familia ".
      "AND codi_questionari LIKE '$resultado'";
#Consulta
$consulta = $conexion->query($q1);
$json = [];

while ($reg = $consulta->fetch_object()) {
  $fila =  [
                            'nom'        => utf8_encode($reg->nom),
                            'descripcio' => utf8_encode($reg->descripcio_curta),
                            'id_curs'    => utf8_encode($reg->id_curs),
                            'itinerari'  => utf8_encode($reg->itinerari),
                            'id_estudis'  =>utf8_encode($reg->id_estudis),
                            'requeriments'=>utf8_encode($reg->requeriments)
  ];
  array_push($json, $fila);
}

echo json_encode($json);

















?>
