<?php

$json = json_decode( file_get_contents('http://192.168.2.208/rest/familia'), true );
echo json_encode($json);

?>
