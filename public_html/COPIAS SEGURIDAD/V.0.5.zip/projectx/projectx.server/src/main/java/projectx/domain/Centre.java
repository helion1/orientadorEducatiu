/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectx.domain;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import org.codehaus.jackson.annotate.JsonIgnore;

/**
 *
 * @author mange
 */
@Entity
@Table(name = "centre")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Centre.findAll", query = "SELECT c FROM Centre c")
    , @NamedQuery(name = "Centre.findByCodiCentre", query = "SELECT c FROM Centre c WHERE c.codiCentre = :codiCentre")
    , @NamedQuery(name = "Centre.findByNom", query = "SELECT c FROM Centre c WHERE c.nom = :nom")
    , @NamedQuery(name = "Centre.findByDireccio", query = "SELECT c FROM Centre c WHERE c.direccio = :direccio")
    , @NamedQuery(name = "Centre.findByNaturalesa", query = "SELECT c FROM Centre c WHERE c.naturalesa = :naturalesa")
    , @NamedQuery(name = "Centre.findByCodiPostal", query = "SELECT c FROM Centre c WHERE c.codiPostal = :codiPostal")
    , @NamedQuery(name = "Centre.findByTelefon", query = "SELECT c FROM Centre c WHERE c.telefon = :telefon")
    , @NamedQuery(name = "Centre.findByMunicipi", query = "SELECT c FROM Centre c WHERE c.municipi = :municipi")
    , @NamedQuery(name = "Centre.findByCoordenadaX", query = "SELECT c FROM Centre c WHERE c.coordenadaX = :coordenadaX")
    , @NamedQuery(name = "Centre.findByCoordenadaY", query = "SELECT c FROM Centre c WHERE c.coordenadaY = :coordenadaY")
    , @NamedQuery(name = "Centre.findByEmail", query = "SELECT c FROM Centre c WHERE c.email = :email")
    , @NamedQuery(name = "Centre.findByB", query = "SELECT c FROM Centre c WHERE c.b = :b")
    , @NamedQuery(name = "Centre.findByM", query = "SELECT c FROM Centre c WHERE c.m = :m")
    , @NamedQuery(name = "Centre.findByS", query = "SELECT c FROM Centre c WHERE c.s = :s")})
public class Centre implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "codi_centre")
    private Integer codiCentre;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "nom")
    private String nom;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "direccio")
    private String direccio;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 7)
    @Column(name = "naturalesa")
    private String naturalesa;
    @Basic(optional = false)
    @NotNull
    @Column(name = "codi_postal")
    private int codiPostal;
    @Basic(optional = false)
    @NotNull
    @Column(name = "telefon")
    private int telefon;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "municipi")
    private String municipi;
    @Basic(optional = false)
    @NotNull
    @Column(name = "Coordenada_X")
    private double coordenadaX;
    @Basic(optional = false)
    @NotNull
    @Column(name = "Coordenada_Y")
    private double coordenadaY;
    // @Pattern(regexp="[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", message="Invalid email")//if the field contains email address consider using this annotation to enforce field validation
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "Email")
    private String email;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 6)
    @Column(name = "B")
    private String b;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 6)
    @Column(name = "M")
    private String m;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 6)
    @Column(name = "S")
    private String s;
    @JoinTable(name = "centre_curs", joinColumns = {
        @JoinColumn(name = "codi_centre", referencedColumnName = "codi_centre")}, inverseJoinColumns = {
        @JoinColumn(name = "id_curs", referencedColumnName = "id_curs")})
    @ManyToMany
    private Collection<Curs> cursCollection;
    @JoinColumn(name = "id_comarca", referencedColumnName = "id_comarca")
    @ManyToOne(optional = false)
    private Comarca idComarca;
    @JoinColumn(name = "id_provincia", referencedColumnName = "id_provincia")
    @ManyToOne(optional = false)
    private Provincia idProvincia;

    public Centre() {
    }

    public Centre(Integer codiCentre) {
        this.codiCentre = codiCentre;
    }

    public Centre(Integer codiCentre, String nom, String direccio, String naturalesa, int codiPostal, int telefon, String municipi, double coordenadaX, double coordenadaY, String email, String b, String m, String s) {
        this.codiCentre = codiCentre;
        this.nom = nom;
        this.direccio = direccio;
        this.naturalesa = naturalesa;
        this.codiPostal = codiPostal;
        this.telefon = telefon;
        this.municipi = municipi;
        this.coordenadaX = coordenadaX;
        this.coordenadaY = coordenadaY;
        this.email = email;
        this.b = b;
        this.m = m;
        this.s = s;
    }

    public Integer getCodiCentre() {
        return codiCentre;
    }

    public void setCodiCentre(Integer codiCentre) {
        this.codiCentre = codiCentre;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getDireccio() {
        return direccio;
    }

    public void setDireccio(String direccio) {
        this.direccio = direccio;
    }

    public String getNaturalesa() {
        return naturalesa;
    }

    public void setNaturalesa(String naturalesa) {
        this.naturalesa = naturalesa;
    }

    public int getCodiPostal() {
        return codiPostal;
    }

    public void setCodiPostal(int codiPostal) {
        this.codiPostal = codiPostal;
    }

    public int getTelefon() {
        return telefon;
    }

    public void setTelefon(int telefon) {
        this.telefon = telefon;
    }

    public String getMunicipi() {
        return municipi;
    }

    public void setMunicipi(String municipi) {
        this.municipi = municipi;
    }

    public double getCoordenadaX() {
        return coordenadaX;
    }

    public void setCoordenadaX(double coordenadaX) {
        this.coordenadaX = coordenadaX;
    }

    public double getCoordenadaY() {
        return coordenadaY;
    }

    public void setCoordenadaY(double coordenadaY) {
        this.coordenadaY = coordenadaY;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getB() {
        return b;
    }

    public void setB(String b) {
        this.b = b;
    }

    public String getM() {
        return m;
    }

    public void setM(String m) {
        this.m = m;
    }

    public String getS() {
        return s;
    }

    public void setS(String s) {
        this.s = s;
    }

    @XmlTransient
    @JsonIgnore
    public Collection<Curs> getCursCollection() {
        return cursCollection;
    }

    public void setCursCollection(Collection<Curs> cursCollection) {
        this.cursCollection = cursCollection;
    }

    public Comarca getIdComarca() {
        return idComarca;
    }

    public void setIdComarca(Comarca idComarca) {
        this.idComarca = idComarca;
    }

    public Provincia getIdProvincia() {
        return idProvincia;
    }

    public void setIdProvincia(Provincia idProvincia) {
        this.idProvincia = idProvincia;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (codiCentre != null ? codiCentre.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Centre)) {
            return false;
        }
        Centre other = (Centre) object;
        if ((this.codiCentre == null && other.codiCentre != null) || (this.codiCentre != null && !this.codiCentre.equals(other.codiCentre))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "cat.xtec.ioc.domain.Centre[ codiCentre=" + codiCentre + " ]";
    }
    
}
