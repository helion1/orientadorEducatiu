/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectx.domain;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import org.codehaus.jackson.annotate.JsonIgnore;

/**
 *
 * @author mange
 */
@Entity
@Table(name = "curs")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Curs.findAll", query = "SELECT c FROM Curs c")
    , @NamedQuery(name = "Curs.findByIdCurs", query = "SELECT c FROM Curs c WHERE c.idCurs = :idCurs")
    , @NamedQuery(name = "Curs.findByNom", query = "SELECT c FROM Curs c WHERE c.nom = :nom")
    , @NamedQuery(name = "Curs.findByDescripcioCurta", query = "SELECT c FROM Curs c WHERE c.descripcioCurta = :descripcioCurta")
    , @NamedQuery(name = "Curs.findByDescripcioLlarga", query = "SELECT c FROM Curs c WHERE c.descripcioLlarga = :descripcioLlarga")
    , @NamedQuery(name = "Curs.findByPreu", query = "SELECT c FROM Curs c WHERE c.preu = :preu")
    , @NamedQuery(name = "Curs.findByDuracio", query = "SELECT c FROM Curs c WHERE c.duracio = :duracio")
    , @NamedQuery(name = "Curs.findByParaulesClau", query = "SELECT c FROM Curs c WHERE c.paraulesClau = :paraulesClau")
    , @NamedQuery(name = "Curs.findByCodiQuestionari", query = "SELECT c FROM Curs c WHERE c.codiQuestionari = :codiQuestionari")
    , @NamedQuery(name = "Curs.findByContingut", query = "SELECT c FROM Curs c WHERE c.contingut = :contingut")
    , @NamedQuery(name = "Curs.findBySortidaLaboral", query = "SELECT c FROM Curs c WHERE c.sortidaLaboral = :sortidaLaboral")})
public class Curs implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 6)
    @Column(name = "id_curs")
    private String idCurs;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "nom")
    private String nom;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 250)
    @Column(name = "descripcio_curta")
    private String descripcioCurta;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 1200)
    @Column(name = "descripcio_llarga")
    private String descripcioLlarga;
    @Basic(optional = false)
    @NotNull
    @Column(name = "preu")
    private double preu;
    @Basic(optional = false)
    @NotNull
    @Column(name = "duracio")
    private int duracio;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 600)
    @Column(name = "paraules_clau")
    private String paraulesClau;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 7)
    @Column(name = "codi_questionari")
    private String codiQuestionari;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 1200)
    @Column(name = "contingut")
    private String contingut;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 1200)
    @Column(name = "sortida_laboral")
    private String sortidaLaboral;
    @ManyToMany(mappedBy = "cursCollection")
    private Collection<Centre> centreCollection;
    @JoinColumn(name = "id_familia", referencedColumnName = "id_familia")
    @ManyToOne(optional = false)
    private Familia idFamilia;
    @JoinColumn(name = "id_estudis", referencedColumnName = "id_estudis")
    @ManyToOne(optional = false)
    private Estudi idEstudis;

    public Curs() {
    }

    public Curs(String idCurs) {
        this.idCurs = idCurs;
    }

    public Curs(String idCurs, String nom, String descripcioCurta, String descripcioLlarga, double preu, int duracio, String paraulesClau, String codiQuestionari, String contingut, String sortidaLaboral) {
        this.idCurs = idCurs;
        this.nom = nom;
        this.descripcioCurta = descripcioCurta;
        this.descripcioLlarga = descripcioLlarga;
        this.preu = preu;
        this.duracio = duracio;
        this.paraulesClau = paraulesClau;
        this.codiQuestionari = codiQuestionari;
        this.contingut = contingut;
        this.sortidaLaboral = sortidaLaboral;
    }

    public String getIdCurs() {
        return idCurs;
    }

    public void setIdCurs(String idCurs) {
        this.idCurs = idCurs;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getDescripcioCurta() {
        return descripcioCurta;
    }

    public void setDescripcioCurta(String descripcioCurta) {
        this.descripcioCurta = descripcioCurta;
    }

    public String getDescripcioLlarga() {
        return descripcioLlarga;
    }

    public void setDescripcioLlarga(String descripcioLlarga) {
        this.descripcioLlarga = descripcioLlarga;
    }

    public double getPreu() {
        return preu;
    }

    public void setPreu(double preu) {
        this.preu = preu;
    }

    public int getDuracio() {
        return duracio;
    }

    public void setDuracio(int duracio) {
        this.duracio = duracio;
    }

    public String getParaulesClau() {
        return paraulesClau;
    }

    public void setParaulesClau(String paraulesClau) {
        this.paraulesClau = paraulesClau;
    }

    public String getCodiQuestionari() {
        return codiQuestionari;
    }

    public void setCodiQuestionari(String codiQuestionari) {
        this.codiQuestionari = codiQuestionari;
    }

    public String getContingut() {
        return contingut;
    }

    public void setContingut(String contingut) {
        this.contingut = contingut;
    }

    public String getSortidaLaboral() {
        return sortidaLaboral;
    }

    public void setSortidaLaboral(String sortidaLaboral) {
        this.sortidaLaboral = sortidaLaboral;
    }

    @XmlTransient
    @JsonIgnore
    public Collection<Centre> getCentreCollection() {
        return centreCollection;
    }

    public void setCentreCollection(Collection<Centre> centreCollection) {
        this.centreCollection = centreCollection;
    }

    public Familia getIdFamilia() {
        return idFamilia;
    }

    public void setIdFamilia(Familia idFamilia) {
        this.idFamilia = idFamilia;
    }

    public Estudi getIdEstudis() {
        return idEstudis;
    }

    public void setIdEstudis(Estudi idEstudis) {
        this.idEstudis = idEstudis;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idCurs != null ? idCurs.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Curs)) {
            return false;
        }
        Curs other = (Curs) object;
        if ((this.idCurs == null && other.idCurs != null) || (this.idCurs != null && !this.idCurs.equals(other.idCurs))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "projectx.domain.Curs[ idCurs=" + idCurs + " ]";
    }
    
}
