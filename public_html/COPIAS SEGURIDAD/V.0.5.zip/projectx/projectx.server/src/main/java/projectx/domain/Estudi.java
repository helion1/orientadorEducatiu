/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectx.domain;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import org.codehaus.jackson.annotate.JsonIgnore;

/**
 *
 * @author mange
 */
@Entity
@Table(name = "estudi")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Estudi.findAll", query = "SELECT e FROM Estudi e")
    , @NamedQuery(name = "Estudi.findByIdEstudis", query = "SELECT e FROM Estudi e WHERE e.idEstudis = :idEstudis")
    , @NamedQuery(name = "Estudi.findByNom", query = "SELECT e FROM Estudi e WHERE e.nom = :nom")
    , @NamedQuery(name = "Estudi.findByRequeriments", query = "SELECT e FROM Estudi e WHERE e.requeriments = :requeriments")})
public class Estudi implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 6)
    @Column(name = "id_estudis")
    private String idEstudis;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "nom")
    private String nom;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 25)
    @Column(name = "requeriments")
    private String requeriments;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idEstudis")
    private Collection<Curs> cursCollection;

    public Estudi() {
    }

    public Estudi(String idEstudis) {
        this.idEstudis = idEstudis;
    }

    public Estudi(String idEstudis, String nom, String requeriments) {
        this.idEstudis = idEstudis;
        this.nom = nom;
        this.requeriments = requeriments;
    }

    public String getIdEstudis() {
        return idEstudis;
    }

    public void setIdEstudis(String idEstudis) {
        this.idEstudis = idEstudis;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getRequeriments() {
        return requeriments;
    }

    public void setRequeriments(String requeriments) {
        this.requeriments = requeriments;
    }

    @XmlTransient
    @JsonIgnore
    public Collection<Curs> getCursCollection() {
        return cursCollection;
    }

    public void setCursCollection(Collection<Curs> cursCollection) {
        this.cursCollection = cursCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idEstudis != null ? idEstudis.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Estudi)) {
            return false;
        }
        Estudi other = (Estudi) object;
        if ((this.idEstudis == null && other.idEstudis != null) || (this.idEstudis != null && !this.idEstudis.equals(other.idEstudis))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "cat.xtec.ioc.domain.Estudi[ idEstudis=" + idEstudis + " ]";
    }
    
}
