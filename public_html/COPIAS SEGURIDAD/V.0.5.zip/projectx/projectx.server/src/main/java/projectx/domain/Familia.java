/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectx.domain;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import org.codehaus.jackson.annotate.JsonIgnore;

/**
 *
 * @author mange
 */
@Entity
@Table(name = "familia")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Familia.findAll", query = "SELECT f FROM Familia f")
    , @NamedQuery(name = "Familia.findByIdFamilia", query = "SELECT f FROM Familia f WHERE f.idFamilia = :idFamilia")
    , @NamedQuery(name = "Familia.findByNom", query = "SELECT f FROM Familia f WHERE f.nom = :nom")
    , @NamedQuery(name = "Familia.findByIntinerari", query = "SELECT f FROM Familia f WHERE f.intinerari = :intinerari")})
public class Familia implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 6)
    @Column(name = "id_familia")
    private String idFamilia;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "nom")
    private String nom;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 6)
    @Column(name = "intinerari")
    private String intinerari;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idFamilia")
    private Collection<Curs> cursCollection;

    public Familia() {
    }

    public Familia(String idFamilia) {
        this.idFamilia = idFamilia;
    }

    public Familia(String idFamilia, String nom, String intinerari) {
        this.idFamilia = idFamilia;
        this.nom = nom;
        this.intinerari = intinerari;
    }

    public String getIdFamilia() {
        return idFamilia;
    }

    public void setIdFamilia(String idFamilia) {
        this.idFamilia = idFamilia;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getIntinerari() {
        return intinerari;
    }

    public void setIntinerari(String intinerari) {
        this.intinerari = intinerari;
    }

    @XmlTransient
    @JsonIgnore
    public Collection<Curs> getCursCollection() {
        return cursCollection;
    }

    public void setCursCollection(Collection<Curs> cursCollection) {
        this.cursCollection = cursCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idFamilia != null ? idFamilia.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Familia)) {
            return false;
        }
        Familia other = (Familia) object;
        if ((this.idFamilia == null && other.idFamilia != null) || (this.idFamilia != null && !this.idFamilia.equals(other.idFamilia))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "projectx.domain.Familia[ idFamilia=" + idFamilia + " ]";
    }
    
}
