package projectx.domain.repository;

import java.util.List;
import projectx.domain.Centre;

public interface CentreRepository {
    List<Centre> getAll(); 
    void add(Centre centre);
    void update(Centre centre);
    void delete(Integer centre);
    Centre get(Integer codicentre);  
}
