package projectx.domain.repository;

import java.util.List;
import projectx.domain.Comarca;

public interface ComarcaRepository {
    List<Comarca> getAll(); 
    void add(Comarca comarca);
    void update(Comarca comarca);
    void delete(Integer comarca);
    Comarca get(Integer codicentre);  
}
