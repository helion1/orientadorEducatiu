package projectx.domain.repository;

import java.util.List;
import projectx.domain.Curs;

public interface CursRepository {
    List<Curs> getAll(); 
    void add(Curs curs);
    void update(Curs curs);
    void delete(String idcurs);
    Curs get(String idcurs); 
}
