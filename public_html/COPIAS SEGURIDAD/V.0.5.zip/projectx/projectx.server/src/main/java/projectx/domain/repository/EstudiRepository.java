package projectx.domain.repository;

import java.util.List;
import projectx.domain.Estudi;

public interface EstudiRepository {
    List<Estudi> getAll(); 
    void add(Estudi estudi);
    void update(Estudi estudi);
    void delete(Integer estudi);
    Estudi get(Integer idestudi);  
    String getRequeriments(Integer codi);
}
