package projectx.domain.repository;

import java.util.List;
import projectx.domain.Familia;

public interface FamiliaRepository {
    List<Familia> getAll(); 
    void add(Familia familia);
    void update(Familia familia);
    void delete(Integer familia);
    Familia get(Integer idfamilia);  
    String getIntinerari(Integer codi);
}
