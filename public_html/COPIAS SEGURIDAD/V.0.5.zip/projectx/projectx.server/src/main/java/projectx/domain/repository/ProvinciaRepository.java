package projectx.domain.repository;

import java.util.List;
import projectx.domain.Provincia;

public interface ProvinciaRepository {
    List<Provincia> getAll(); 
    void add(Provincia provincia);
    void update(Provincia provincia);
    void delete(Integer provincia);
    Provincia get(Integer codicentre);  
}
