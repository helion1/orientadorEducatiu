package projectx.domain.repository.impl;

import projectx.domain.Centre;
import java.util.List;
import javax.annotation.Resource;
import javax.ejb.EJBContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;
import projectx.domain.repository.CentreRepository;

@Stateless
@TransactionManagement(TransactionManagementType.BEAN)
public class CentreRepositoryImpl implements CentreRepository {
    
    @PersistenceContext(unitName = "CentrePersistence")
    private EntityManager entityManager;
    
    @Resource
    private EJBContext context;
    
    @Override
    public void add(Centre centre) {
        UserTransaction utx = context.getUserTransaction();
        try {
            utx.begin();
            entityManager.persist(centre);
            utx.commit();
        } catch (Exception e) {
            e.printStackTrace();
            try {
                utx.rollback();
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }
    }

    public void update(Centre centre) {
        UserTransaction utx = context.getUserTransaction();
        try {
            utx.begin();
            entityManager.merge(centre);
            utx.commit();
        } catch (Exception e) {
            e.printStackTrace();
            try {
                utx.rollback();
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }
    }

    public void delete(Integer centre) {
        UserTransaction utx = context.getUserTransaction();
        try {
            utx.begin();
            entityManager.remove(centre);
            utx.commit();
        } catch (Exception e) {
            e.printStackTrace();
            try {
                utx.rollback();
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }    }

    public Centre get(Integer codi) {
        return (Centre) entityManager.createQuery("select object(c) from Centre c " +
            "where c.codi_centre = :codi_centre")
            .setParameter("codi_centre", codi)
            .getSingleResult();
    }

    public List<Centre> getAll() {
        return (List<Centre>) entityManager.createQuery("select object(c) from Centre c")
            .getResultList();
    }
    
}
