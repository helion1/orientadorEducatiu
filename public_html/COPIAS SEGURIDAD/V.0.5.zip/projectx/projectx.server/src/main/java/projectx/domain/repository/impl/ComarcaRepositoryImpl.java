package projectx.domain.repository.impl;

import java.util.List;
import javax.annotation.Resource;
import javax.ejb.EJBContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;
import projectx.domain.Comarca;
import projectx.domain.repository.ComarcaRepository;

@Stateless
@TransactionManagement(TransactionManagementType.BEAN)
public class ComarcaRepositoryImpl implements ComarcaRepository {
    
    @PersistenceContext(unitName = "ComarcaPersistence")
    private EntityManager entityManager;
    
    @Resource
    private EJBContext context;
    
    @Override
    public void add(Comarca comarca) {
        UserTransaction utx = context.getUserTransaction();
        try {
            utx.begin();
            entityManager.persist(comarca);
            utx.commit();
        } catch (Exception e) {
            e.printStackTrace();
            try {
                utx.rollback();
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }
    }

    public void update(Comarca comarca) {
        UserTransaction utx = context.getUserTransaction();
        try {
            utx.begin();
            entityManager.merge(comarca);
            utx.commit();
        } catch (Exception e) {
            e.printStackTrace();
            try {
                utx.rollback();
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }
    }

    public void delete(Integer comarca) {
        UserTransaction utx = context.getUserTransaction();
        try {
            utx.begin();
            entityManager.remove(comarca);
            utx.commit();
        } catch (Exception e) {
            e.printStackTrace();
            try {
                utx.rollback();
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }    }

    public Comarca get(Integer codi) {
        return (Comarca) entityManager.createQuery("select object(c) from Comarca c " +
            "where c.id_comarca = :idcomarca")
            .setParameter("idcomarca", codi)
            .getSingleResult();
    }

    public List<Comarca> getAll() {
        return (List<Comarca>) entityManager.createQuery("select object(c) from Centre c")
            .getResultList();
    }
    
}
