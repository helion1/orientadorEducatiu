package projectx.domain.repository.impl;

import java.util.List;
import javax.annotation.Resource;
import javax.ejb.EJBContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;
import org.codehaus.jettison.json.JSONObject;
import projectx.domain.Curs;
import projectx.domain.repository.CursRepository;

@Stateless
@TransactionManagement(TransactionManagementType.BEAN)
public class CursRepositoryImpl implements CursRepository {
    
    @PersistenceContext(unitName = "CursPersistence")
    private EntityManager entityManager;
    
    @Resource
    private EJBContext context;
    
    @Override
    public void add(Curs curs) {
        UserTransaction utx = context.getUserTransaction();
        try {
            utx.begin();
            entityManager.persist(curs);
            utx.commit();
        } catch (Exception e) {
            e.printStackTrace();
            try {
                utx.rollback();
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }
    }

    public void update(Curs curs) {
        UserTransaction utx = context.getUserTransaction();
        try {
            utx.begin();
            entityManager.merge(curs);
            utx.commit();
        } catch (Exception e) {
            e.printStackTrace();
            try {
                utx.rollback();
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }
    }

    public void delete(String idcurs) {
        UserTransaction utx = context.getUserTransaction();
        try {
            utx.begin();
            entityManager.remove(idcurs);
            utx.commit();
        } catch (Exception e) {
            e.printStackTrace();
            try {
                utx.rollback();
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }    }

    public Curs get(String idcurs) {
        return (Curs) entityManager.createQuery("select object(c) from Curs c " +
            "where c.id_curs = :idcurs")
            .setParameter("idcurs", idcurs)
            .getSingleResult();
    }

    public List<Curs> getAll() {
        return (List<Curs>) entityManager.createQuery("select object(c) from Curs c")
            .getResultList();
    }

    
}
