package projectx.domain.repository.impl;

import java.util.List;
import javax.annotation.Resource;
import javax.ejb.EJBContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;
import projectx.domain.Estudi;
import projectx.domain.repository.EstudiRepository;

@Stateless
@TransactionManagement(TransactionManagementType.BEAN)
public class EstudiRepositoryImpl implements EstudiRepository {
    
    @PersistenceContext(unitName = "EstudiPersistence")
    private EntityManager entityManager;
    
    @Resource
    private EJBContext context;
    
    @Override
    public void add(Estudi estudi) {
        UserTransaction utx = context.getUserTransaction();
        try {
            utx.begin();
            entityManager.persist(estudi);
            utx.commit();
        } catch (Exception e) {
            e.printStackTrace();
            try {
                utx.rollback();
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }
    }

    public void update(Estudi estudi) {
        UserTransaction utx = context.getUserTransaction();
        try {
            utx.begin();
            entityManager.merge(estudi);
            utx.commit();
        } catch (Exception e) {
            e.printStackTrace();
            try {
                utx.rollback();
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }
    }

    public void delete(Integer centre) {
        UserTransaction utx = context.getUserTransaction();
        try {
            utx.begin();
            entityManager.remove(centre);
            utx.commit();
        } catch (Exception e) {
            e.printStackTrace();
            try {
                utx.rollback();
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }    }

    public Estudi get(Integer codi) {
        return (Estudi) entityManager.createQuery("select object(e) from Estudi e " +
            "where e.id_estudi = :idestudi")
            .setParameter("idestudi", codi)
            .getSingleResult();
    }
    
    public String getRequeriments(Integer codi) {
        return (String) entityManager.createQuery("select e.requeriments from Estudi e " +
            "where e.id_estudis = :idestudis")
            .setParameter("idestudis", codi)
            .getSingleResult();
    }

    public List<Estudi> getAll() {
        return (List<Estudi>) entityManager.createQuery("select object(e) from Estudi e")
            .getResultList();
    }
    
}
