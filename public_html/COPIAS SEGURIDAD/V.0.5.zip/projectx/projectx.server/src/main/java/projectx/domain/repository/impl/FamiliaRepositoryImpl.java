package projectx.domain.repository.impl;

import java.util.List;
import javax.annotation.Resource;
import javax.ejb.EJBContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;
import projectx.domain.Familia;
import projectx.domain.repository.FamiliaRepository;

@Stateless
@TransactionManagement(TransactionManagementType.BEAN)
public class FamiliaRepositoryImpl implements FamiliaRepository {
    
    @PersistenceContext(unitName = "FamiliaPersistence")
    private EntityManager entityManager;
    
    @Resource
    private EJBContext context;
    
    @Override
    public void add(Familia familia) {
        UserTransaction utx = context.getUserTransaction();
        try {
            utx.begin();
            entityManager.persist(familia);
            utx.commit();
        } catch (Exception e) {
            e.printStackTrace();
            try {
                utx.rollback();
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }
    }

    public void update(Familia familia) {
        UserTransaction utx = context.getUserTransaction();
        try {
            utx.begin();
            entityManager.merge(familia);
            utx.commit();
        } catch (Exception e) {
            e.printStackTrace();
            try {
                utx.rollback();
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }
    }

    public void delete(Integer centre) {
        UserTransaction utx = context.getUserTransaction();
        try {
            utx.begin();
            entityManager.remove(centre);
            utx.commit();
        } catch (Exception e) {
            e.printStackTrace();
            try {
                utx.rollback();
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }    }

    public Familia get(Integer codi) {
        return (Familia) entityManager.createQuery("select object(f) from Familia f " +
            "where f.id_familia = :idfamilia")
            .setParameter("idfamilia", codi)
            .getSingleResult();
    }
    
    public String getIntinerari(Integer codi) {
        return (String) entityManager.createQuery("select f.intinerari from Familia f " +
            "where f.id_familia = :idfamilia")
            .setParameter("idfamilia", codi)
            .getSingleResult();
    }

    public List<Familia> getAll() {
        return (List<Familia>) entityManager.createQuery("select object(f) from Familia f")
            .getResultList();
    }
    
}
