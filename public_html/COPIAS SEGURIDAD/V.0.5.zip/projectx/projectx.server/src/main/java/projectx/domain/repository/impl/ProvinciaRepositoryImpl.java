package projectx.domain.repository.impl;

import java.util.List;
import javax.annotation.Resource;
import javax.ejb.EJBContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;
import projectx.domain.Provincia;
import projectx.domain.repository.ProvinciaRepository;

@Stateless
@TransactionManagement(TransactionManagementType.BEAN)
public class ProvinciaRepositoryImpl implements ProvinciaRepository {
    
    @PersistenceContext(unitName = "ProvinciaPersistence")
    private EntityManager entityManager;
    
    @Resource
    private EJBContext context;
    
    @Override
    public void add(Provincia provincia) {
        UserTransaction utx = context.getUserTransaction();
        try {
            utx.begin();
            entityManager.persist(provincia);
            utx.commit();
        } catch (Exception e) {
            e.printStackTrace();
            try {
                utx.rollback();
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }
    }

    public void update(Provincia provincia) {
        UserTransaction utx = context.getUserTransaction();
        try {
            utx.begin();
            entityManager.merge(provincia);
            utx.commit();
        } catch (Exception e) {
            e.printStackTrace();
            try {
                utx.rollback();
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }
    }

    public void delete(Integer centre) {
        UserTransaction utx = context.getUserTransaction();
        try {
            utx.begin();
            entityManager.remove(centre);
            utx.commit();
        } catch (Exception e) {
            e.printStackTrace();
            try {
                utx.rollback();
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }    }

    public Provincia get(Integer codi) {
        return (Provincia) entityManager.createQuery("select object(p) from Provincia p " +
            "where p.id_provincia = :idprovincia")
            .setParameter("idprovincia", codi)
            .getSingleResult();
    }

    public List<Provincia> getAll() {
        return (List<Provincia>) entityManager.createQuery("select object(p) from Provincia p")
            .getResultList();
    }
    
}
