package projectx.service;

import java.net.URI;
import java.util.List;
import javax.ejb.Singleton;
import javax.ws.rs.BadRequestException;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import projectx.domain.Comarca;
import projectx.domain.repository.ComarcaRepository;
import projectx.domain.repository.impl.ComarcaRepositoryImpl;


@Path("/comarca")
@Singleton
public class ComarcaService {
    private final ComarcaRepository comarcaRepository = new ComarcaRepositoryImpl();
    @Context private UriInfo uriInfo;
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Comarca> getAll() {
    return this.comarcaRepository.getAll();
    }

    @GET
    @Path("{idcomarca}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response find(@PathParam("idcomarca") Integer codicentre) {
        Comarca centre = this.comarcaRepository.get(codicentre);
        if(centre == null) {
            throw new NotFoundException();
        }
        return Response.ok(centre).build();
    }

    @GET
    @Path("findById/{Id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Comarca findByCodi(@PathParam("codi") Integer codi) {
    return this.comarcaRepository.get(codi);
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response create(Comarca comarca) {
        if(comarca == null) {
            throw new BadRequestException();
        }
        this.comarcaRepository.add(comarca);
        URI centreUri = uriInfo.getAbsolutePathBuilder().path(String.valueOf(comarca.getIdComarca())).build();
        return Response.ok(centreUri).build();
    }

    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    public void edit(Comarca centre) {
        this.comarcaRepository.update(centre);
    }

    @DELETE
    @Path("{idcomarca}")
    public void remove(@PathParam("idcomarca") Integer codi) {
    this.comarcaRepository.delete(codi);
    }

}
