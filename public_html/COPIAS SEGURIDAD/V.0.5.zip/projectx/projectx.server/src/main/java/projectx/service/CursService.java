package projectx.service;

import projectx.domain.Curs;
import projectx.domain.repository.CursRepository;
import projectx.domain.repository.impl.CursRepositoryImpl;
import java.net.URI;
import java.util.List;
import javax.ejb.Singleton;
import javax.ws.rs.BadRequestException;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;


@Path("/curs")
@Singleton
public class CursService {
    private final CursRepository centreRepository = new CursRepositoryImpl();
    @Context private UriInfo uriInfo;
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Curs> getAll() {
    return this.centreRepository.getAll();
    }

    @GET
    @Path("{idcurs}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response find(@PathParam("idcurs") String idcurs) {
        Curs curs = this.centreRepository.get(idcurs);
        if(curs == null) {
            throw new NotFoundException();
        }
        return Response.ok(curs).build();
    }

    @GET
    @Path("findById/{Id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Curs findById(@PathParam("codi") String idcurs) {
    return this.centreRepository.get(idcurs);
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response create(Curs curs) {
        if(curs == null) {
            throw new BadRequestException();
        }
        this.centreRepository.add(curs);
        URI centreUri = uriInfo.getAbsolutePathBuilder().path(curs.getIdCurs()).build();
        return Response.ok(centreUri).build();
    }

    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    public void edit(Curs curs) {
        this.centreRepository.update(curs);
    }

    @DELETE
    @Path("{idcurs}")
    public void remove(@PathParam("idcurs") String idcurs) {
    this.centreRepository.delete(idcurs);
    }

}
