package projectx.service;

import java.net.URI;
import java.util.List;
import javax.ejb.Singleton;
import javax.ws.rs.BadRequestException;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import projectx.domain.Estudi;
import projectx.domain.repository.EstudiRepository;
import projectx.domain.repository.impl.EstudiRepositoryImpl;


@Path("/estudi")
@Singleton
public class EstudiService {
    private final EstudiRepository estudiRepository = new EstudiRepositoryImpl();
    @Context private UriInfo uriInfo;
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Estudi> getAll() {
    return this.estudiRepository.getAll();
    }

    @GET
    @Path("{idestudi}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response find(@PathParam("idestudi") Integer codicentre) {
        Estudi centre = this.estudiRepository.get(codicentre);
        if(centre == null) {
            throw new NotFoundException();
        }
        return Response.ok(centre).build();
    }

    @GET
    @Path("findById/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Estudi findByCodi(@PathParam("id") Integer codi) {
    return this.estudiRepository.get(codi);
    }
    
    @GET
    @Path("requeriments/{idestudi}")
    @Produces(MediaType.APPLICATION_JSON)
    public String Intinerari(@PathParam("id") Integer codi) {
        return this.estudiRepository.getRequeriments(codi);
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response create(Estudi estudi) {
        if(estudi == null) {
            throw new BadRequestException();
        }
        this.estudiRepository.add(estudi);
        URI centreUri = uriInfo.getAbsolutePathBuilder().path(String.valueOf(estudi.getIdEstudis())).build();
        return Response.ok(centreUri).build();
    }

    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    public void edit(Estudi estudi) {
        this.estudiRepository.update(estudi);
    }

    @DELETE
    @Path("{idestudi}")
    public void remove(@PathParam("idestudi") Integer codicentre) {
    this.estudiRepository.delete(codicentre);
    }

}
