package projectx.service;

import java.net.URI;
import java.util.List;
import javax.ejb.Singleton;
import javax.ws.rs.BadRequestException;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import projectx.domain.Provincia;
import projectx.domain.repository.ProvinciaRepository;
import projectx.domain.repository.impl.ProvinciaRepositoryImpl;


@Path("/provincia")
@Singleton
public class ProvinciaService {
    private final ProvinciaRepository provinciaRepository = new ProvinciaRepositoryImpl();
    @Context private UriInfo uriInfo;
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Provincia> getAll() {
    return this.provinciaRepository.getAll();
    }

    @GET
    @Path("{idprovincia}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response find(@PathParam("idprovincia") Integer codicentre) {
        Provincia provincia = this.provinciaRepository.get(codicentre);
        if(provincia == null) {
            throw new NotFoundException();
        }
        return Response.ok(provincia).build();
    }

    @GET
    @Path("findById/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Provincia findByCodi(@PathParam("id") Integer codi) {
        return this.provinciaRepository.get(codi);
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response create(Provincia provincia) {
        if(provincia == null) {
            throw new BadRequestException();
        }
        this.provinciaRepository.add(provincia);
        URI centreUri = uriInfo.getAbsolutePathBuilder().path(String.valueOf(provincia.getIdProvincia())).build();
        return Response.ok(centreUri).build();
    }

    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    public void edit(Provincia provincia) {
        this.provinciaRepository.update(provincia);
    }

    @DELETE
    @Path("{idprovincia}")
    public void remove(@PathParam("idprovincia") Integer codicentre) {
    this.provinciaRepository.delete(codicentre);
    }

}
